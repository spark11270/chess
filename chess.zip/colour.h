#ifndef COLOR_H
#define COLOR_H

enum class Colour { Black, White };

#endif
