#ifndef _PIECENAME_H_
#define _PIECENAME_H_

enum class PieceName {
    King = 0, 
    Queen, 
    Bishop, 
    Rook, 
    Knight, 
    Pawn
};

#endif
